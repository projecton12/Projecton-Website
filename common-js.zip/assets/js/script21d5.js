(function($){
	'use strict';
	var $win = $(window), $body_m = $('body'), $navbar = $('.navbar');

	// Touch Class
	if (!("ontouchstart" in document.documentElement)) {
		$body_m.addClass("no-touch");
	}
	// Get Window Width
	function winwidth () {
		return $win.width();
	}
	var wwCurrent = winwidth();
	$win.on('resize', function () { 
		wwCurrent = winwidth(); 
	});

	// Stick
	var $is_sticky = $('.is-sticky');
	if ($is_sticky.length > 0 ) {
		var $navm = $('#mainnav').offset();
		$win.scroll(function(){
			var $scroll = $win.scrollTop();
			if ($win.width() > 991 || $is_sticky.hasClass('mobile-sticky')) {
				if($scroll > $navm.top ){
					if(!$is_sticky.hasClass('has-fixed')) {$is_sticky.addClass('has-fixed');}
					// $(".back").show();
				} else {
					if($is_sticky.hasClass('has-fixed')) {$is_sticky.removeClass('has-fixed');}
                    // $(".back").hide();
				}
			} else {
				if($is_sticky.hasClass('has-fixed')) {$is_sticky.removeClass('has-fixed');}
			}
		});
	}
	
	// OnePage Scrolling
	$('a.menu-link[href*="#"]:not([href="#"]),a#backTop').on("click", function() {
		if (location.pathname.replace(/^\//, '') === this.pathname.replace(/^\//, '') && location.hostname === this.hostname) {
			var toHash = $(this.hash), toHashN = (this.hash.slice(1)) ? $('[name=' + this.hash.slice(1) + ']') : false, nbar = (wwCurrent >= 992) ? $navbar.height() - 1 : 0;

			toHash = toHash.length ? toHash : toHashN;
			if (toHash.length) {
				$('html, body').animate({
					scrollTop: (toHash.offset().top - nbar)
				}, 1000, "easeInOutExpo");
				return false;
			}
		}
	});
	
	// Active page menu when click
	var CurURL = window.location.href, urlSplit = CurURL.split("#");
	var $nav_link = $(".nav li a");
	if ($nav_link.length > 0) {
		$nav_link.each(function() {
			if (CurURL === (this.href) && (urlSplit[1]!=="")) {
				$(this).closest("li").addClass("active").parent().closest("li").addClass("active");
			}
		});
	}
	
	// Bootstrap Dropdown 
	var $dropdown_menu = $('.dropdown'), $dropdown_toggle = $('.dropdown-toggle');	
	if ($dropdown_menu.length > 0 ) {
		$dropdown_menu.on("mouseover",function(){
			if ($win.width() > 991) {
				$(this).children('.dropdown-menu').stop().fadeIn(400);
				$(this).addClass('open'); 
			}
		});
		$dropdown_menu.on("mouseleave",function(){
			if ($win.width() > 991) {
				$(this).children('.dropdown-menu').stop().fadeOut(400);
				$(this).removeClass('open'); 
			}
		});
		$dropdown_toggle.on("click",function(){
			if ($win.width() < 991) {
				$(this).parent().children('.dropdown-menu').fadeToggle(400);
				$(this).parent().toggleClass('open');
				return false;
			}
		});
	}

	$win.on('resize', function() {
		$('.navbar-collapse').removeClass('in');
		$dropdown_menu.parent().children('.dropdown-menu').fadeOut("400");
	});

	// remove ani
	var $navtoggler = $('.navbar-toggler'), $trannav =$('.is-transparent');
	if ($navtoggler.length > 0) {
		$navtoggler.on("click",function(){
			$('.remove-animation').removeClass('animated');
			if (!$trannav.hasClass('active')) {
				$trannav.addClass('active');
			}else{
				$trannav.removeClass('active');
			}
		});
	}
	
	// Nav collapse
	$('.menu-link').on("click",function() {
		$('.navbar-collapse').collapse('hide');
		$trannav.removeClass('active');
	});
	$(document).on('mouseup', function(e){
		if (!$trannav.is(e.target) && $trannav.has(e.target).length===0) {
			$('.navbar-collapse').collapse('hide');
			$trannav.removeClass('active');
		}
	});

    // Preloader
    var $preload = $('#preloader'), $loader = $('#loader');
    if ($preload.length > 0) {
    	console.log("load")
        $win.on('load', function() {
            $loader.fadeOut(300);
            $body_m.addClass("loaded");
            $preload.delay(700).fadeOut(300);
        });
    }

    function updateCountdown(event) {
		$("#countdown-days").text(event.strftime('%D'));
		$("#countdown-hours").text(event.strftime('%H'));
		$("#countdown-mins").text(event.strftime('%M'));
		$("#countdown-secs").text(event.strftime('%S'));
	}

    //For release
    var preStartTime = new Date("2019/03/25 00:00:00 GMT+0");
    var preEndTime = new Date("2019/04/25 06:00:00 GMT+0");
    var ieoEndTime = new Date("2019/05/04 06:00:00 GMT+0");
    var publicStartTime = new Date("2019/06/01 00:00:00 GMT+0");
    var publicEndTime = new Date("2019/09/01 00:00:00 GMT+0");

    var stages = [
		{ title: "PRE SALE STARTS iN" , time: preStartTime },
        { title: "FAIREUM IEO STARTS IN" , time: preEndTime },
        { title: "FAIREUM IEO ENDS IN" , time: ieoEndTime },
        { title: "PUBLIC SALE STARTS IN" , time: publicStartTime },
        { title: "PUBLIC SALE ENDS IN" , time: publicEndTime },
	];

	// Count Down
	var $count_token = $('.token-countdown');
	if ($count_token.length > 0 ) {
		$count_token.each(function() {
			var $self = $(this), text = $("#textIco");

			//check the time circle
            var stageItem, datetime;
            while(stages.length > 0) {
                stageItem = stages.shift();
                datetime = stageItem.time;
                if(Date.now() < datetime) {
                	break;
				}
			}
            text.text(stageItem.title)

			$self.countdown(datetime)
			.on('update.countdown', function(event){updateCountdown(event)})
			.on('finish.countdown', function(event) {
				console.log(event.timeStamp)
				if(stages.length > 0) {
                    stageItem = stages.shift()
					datetime = stageItem.time;
                    text.text(stageItem.title)
					$self.countdown(datetime)
				}else{
                    text.text("ICO ENDED")
                    $("#countdown-days").text('00');
                    $("#countdown-hours").text('00');
                    $("#countdown-mins").text('00');
                    $("#countdown-secs").text('00');
				}
			});
		});
	}

    //POPUP - Video
    var $video_play = $('.video-play');
    if ($video_play.length > 0 ) {
    	$video_play.magnificPopup({
    		type: 'iframe',
    		removalDelay: 160,
    		preloader: true,
    		fixedContentPos: false,
            callbacks: {
                beforeAppend: function() {
                    console.log('before iframe is added to DOM');
                    this.content.find('iframe').on('load', function() {
                        console.log('iframe loaded');
                    });
                }
            }
    	});
    }

	// On Scroll Animation
	var $aniKey = $('.animated');
	if($().waypoint && $aniKey.length > 0){
		$win.on('load', function() {
			$aniKey.each(function(){
			var aniWay = $(this), typ = aniWay.data("animate"), dur = aniWay.data("duration"), dly = aniWay.data("delay");
			aniWay.waypoint(function(){
				aniWay.addClass("animated "+typ).css("visibility", "visible");
				if(dur){ 
					aniWay.css('animation-duration', dur+'s'); 
				}
				if(dly){ 
					aniWay.css('animation-delay', dly+'s'); 
				}
				}, { offset: '93%' });
			});
		});
	}
	
    // FAQ
	var $card = $('.card');
	if ($card.length > 0) {
		$card.each(function(){
			var $cha = $('.card-header a') ;
			$cha.on('click', function(){
                var $this = $(this);
                $this.parent().parent().parent().parent().find($card).removeClass('active');
				$this.parent().parent().parent().addClass('active');
			});
		});
	}

    // END - Subscribe mail

    new TypeIt('#sologan', {
        speed: 100,
        waitUntilVisible: true
    })
	.pause(2000)
	.type('Customer Satisfaction First.')
	.go()

    new TypeIt('#ieo', {
        speed: 50,
        waitUntilVisible: true
    })
        .pause(3500)
        .type('Faireum\'s IEO will be starting soon.')
        .go()

	setTimeout(function () {
        $('.single-ranks').liMarquee();
        $('.single-partner').liMarquee();
        $('.single-media').liMarquee();
        $('.flexslider').flexslider({
            animation: "slide"
        });
    }, 1000)

    $.ajax({
        url: "https://api.faireum.io/api/getPayments",
        type: "POST",
        data: null ,
        success: function (response) {
            // you will get response from your php page (what you echo or print)
            setTimeout(function() {
                let raisedUSD = new CountUp('raisedUSD', 0, response["total_success_usd"]);
                raisedUSD.start();

                let ieoRaised = new CountUp('ieoRaised', 0, 50000);
                let ieoCap = new CountUp('ieoCap', 0, 250000);
                ieoRaised.start();
                ieoCap.start();
            }, 500)
        },
        error: function(jqXHR, textStatus, errorThrown) {
            setTimeout(function() {
                let raisedUSD = new CountUp('raisedUSD', 0, 511604);

                raisedUSD.start();

                let ieoRaised = new CountUp('ieoRaised', 0, 50000);
                let ieoCap = new CountUp('ieoCap', 0, 250000);
                ieoRaised.start();
                ieoCap.start();
            }, 1000)
        }
    });

})(jQuery);