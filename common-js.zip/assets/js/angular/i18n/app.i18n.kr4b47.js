var localeKr = {

    common: {

        domain: 'https://faireum.io',

        languageCode: 'Kr',

        language: '한국어',

        projectName: 'Faireum',

        copyright: '© 2018-2019 Faireum Foundation Limited. All rights reserved ',

        more: 'More',

        privacyPolicy: '개인 정보 취급 방침',

        useTerms: '판매 조건',

        riskWarning: '면책 및 위험 고지',

        auditReport: '스마트 콘트랙트 심사보고서',

        presentation: 'Faireum presentation',

        dashboard: 'ICO 정보',

        buyTokens: '토큰 주문',

        join: '가입',

        download: '다운로드',

        textIcoStart: 'PRE SALE STARTING IN',

        whitepaper: '백서',

        onepager: 'One Pager',

        sologan1: 'Once Fair',

        sologan2: 'Always Fair',

        sologanRemark: '모두를 위한 공평한 게이밍 블록체인 네트워크',

        intro: 'Faireum은 게이밍 업계에 초점을 맞춘 온라인 플렛폼을 바꿀 퍼블릭 블록체인 입니다.',

        text: {

            days: '일',

            hours: '시',

            mins: '분',

            secs: '초',

        },

        inputs: {

            submit: '제출',

            name: '이름',

            email: '이메일',

            message: '메시지',

        },

        titles: {

            home: 'Home',

            about: 'About',

            business: ' Business ',

            problem: 'Problems',

            solution: 'Solution',

            token: 'Token',

            download: 'Download',

            roadmap: 'Road Map',

            partners: 'Partner',

            team: 'Team',

            faq: 'FAQ',

            contact: 'Contact',

            subscribe: 'Subscribe',

        },
        branding: {
            soldout: '총 50만 달러의 FAIRC 예매 단계에서 모두 팔렸다.',
            ieosoon: '1차 페리움 IEO는 5만 달러짜리 대박이 1시간 만에 동났다.',
            ieoRounds: "IEO 라운드 수",
            ieoRaised: "1차 IEO 모금액",
            ieoCap: "다음 라운드 IEO",
            waitingPay: "결제 대기 중",
            raised: "PRE-ICO 모금 된 금액",
            processing: "지불 처리",
            brandingRating: "Faireum은 자랑스럽게 우리가 세계에서 상위 5 위의 ICO 등급 웹 사이트를 수상했다고 발표했습니다.",
            brandingExchanges: "Faireum은 ICO가 끝난 후 세계 상위 10 개 거래소 중 3 개 이상에 상장 될 예정이다.",
            brandingMedia: "Faireum 프로젝트에 대한 정보와 보고서를 발표 한 주류 언론 매체가 100 개가 넘습니다.",
            brandingPandora: "Faireum은 5 월 중순 경에 새롭고 혁신적인 게임 플랫폼을 출시 할 것입니다.",
            brandingJapan: "Faireum은 대중에게 강력한 브랜드 영향력을 행사하는 데 전념하는 합법적 인 운영 프로젝트입니다.",
            brandingSecurity: "Faireum의 똑똑한 계약은 세계 최고의 보안 감사 회사 인 SmartDec의 보안 감사를 통과했습니다.",
            brandingEconomic: "우리는 언제나 환영 받고 투자 요구를 충족시킵니다！",
        }
    },

    module: {
        platform: {
            title: 'Faireum Games',
            description: 'Faireum 플랫폼에서 다양한 게임을 즐기세요.',
            remark: 'Faireum 게임 플랫폼에는 이미 발표 된 수천개의 게임 (Beta 버전)이 있습니다.  우리와 함께 Faireum 플랫폼에서 게임을 즐깁시다.'
        },
        about: {

            whatFaireum: ' Faireum이란?',

            explainFaireum1: 'Faireum은 퍼블릭 블록체인과 수많은 프로토콜로 구성 되였으며 온라인 게이밍 업계의 문제에 초점을 맞추고 탈중앙화 되고 저렴한 비용의 투명하고 안전한 베팅과 게이밍 서비스를   제공합니다.',

            explainFaireum2: '이을 달성하기 위해, Faireum은 토큰과 스마트 게임 콘트랙트를 통해 사용자에게 복권, 경마, 스포츠 베팅, 카지노 게임, 디지털 게임 및 그 외 수많은 서비스에 대한 프리미엄 베팅 경험과 탁월한 서비스를 보장합니다.',

            explainFaireum3: '스마트 클라이어트는 Faireum의 수많은 프로토콜과 함께 Faireum 노드 사용자에게 안전하고 유창한 온라인 게이밍 서비스를 제공합니다.',

            basicFramework: '베이직 프레임 워크',

            explainBasicFramework1: 'Faireum은 게이밍 업계 퍼블릭 블록체인을 개발하여 게이밍 플랫폼에 튼튼한 기술기반과 후원이 되고 있습니다.',

            explainBasicFramework2: 'Faireum 블록체인 생태계는 네트워크 노드, P2P 네트워크, 스마트 콘트랙트 용 가상 시스템 및 토큰 배포 규칙, 토큰 보상, 엑스체인지, 디지털 자산 거래 및 크로스 체인 원자 교환을 포함하는 일련의 규칙을 포함합니다.',

        },

        business: {

            gamesOnFaireum: ' Faireum Blockchain게임',

            gamesRemark: '사용자는 저희의 게임 플렛폼에서 수많은 게임을 찾을수 있으며 오피셜 게임을 포함한 저희의 파트너가 제공한 최적의 서비스를 체험할 수 있습니다.',

            gamesLottery: '복권',

            gamesCasino: '카지노',

            gamesDigital: '디지털 게임',

            gamesBetting: '스포츠 베팅',

            gamesLotteryRemark: '복권은 게이밍의 한 종류로서 주로 숫자의 조합에 따라 당첨결과를 확정하는 일종의 게이밍 방식입니다.',

            gamesCasinoRemark: '카지노는 다양한 게이밍과 게임을 할수 있는 곳으로 고객은 카지노를 통해 확률론에 기초한 게이밍 게임을 할수 있습니다.',

            gamesDigitalRemark: '디지털 게임은 인터넷을 통해 진행되는 시각화 게이밍의 일종으로 전통적인 게이밍에 비해 역사가 짧지만 경기 수준까지 달성한 새로운 형태의 게이밍입니다.',

            gamesBettingRemark: '스포츠 베팅은 스포츠 경기의 결과를 예측하고 각종 스포츠 사건을 예측하는 등 결과나 사건에 베팅하는 것입니다.',

            ourApps: '비즈니스 상업용 앱',

            smartNode: ' Faireum 의 스마트 노드',

            smartNodeRemark: 'Faireum 스마트 노드 (FSN)는 사용자의 컴퓨터 혹은 핸드폰에서 실행되는 블록체인 노드 서버로 스마트 클라이언트 월렛, 프록시서버, 게임센터 등 여러가지 형태로 운행에 참여 할 수 있습니다.',

            explainSmartNode1: '블록체인 노드 서비스로 작동합니다.',

            explainSmartNode2: '클라이언트 서비스 통합으로 사용합니다.',

            explainSmartNode3: '다종 월렛이나 게임 센터로 사용 가능 합니다.',

            explainSmartNode4: '스마트 교환 및 스마트 노드 파트너 서비스를 제공합니다.',

        },

        solution: {

            problemsTitle: '게이밍 산업의 문제점',

            problemsRemark: '현재 게이밍 산업은 다음과 같은 문제에 직면하고 있습니다.',

            solutionTitle: 'Faireum Blockchain Solutions',

            transparency: '안전 및 투명성의 부족',

            negative: '부정적 사회 평판',

            unfair: '불공평',

            fees: '높은 수수료',

            security: '보안',

            tax: '탈세 및 돈세탁',

            transparencyRemark: '중앙화 시스템은 자원을 대중에게 공개하지 않아 외부에서 개발 업그레이드에 참여하기 어렵습니다.',

            negativeRemark: '실시간 온라인 게임에서 플레이어는 상대방에 대한 불확실성과 회의감을 가지고 있습니다.',

            unfairRemark: '게이밍 플랫폼은 매개 변수의 수정을 통해  렌덤남버 생성기 (RNG)를 조절하여 플레이어에 대한 확률을 결정합니다.',

            feesRemark: '게이밍 플랫폼의 수익 모델은 게이밍 운영 자의 높은 요금을 초래 합니다.',

            securityRemark: '중앙화 시스템은 100 % 보안을 보장 할 수 없으며 높은 내고장성을 보장 할 수 없습니다.',

            taxRemark: '온라인 게이밍은 현지 세금 메커니즘에 적합하지 않고 돈세탁 위험도 있습니다.',

            explainSolution1: 'Faireum은 제3자가 공유 메커니즘 및 Faireum Virtual Machine (FVM)을 통해 액세스하는 데 적합한 API (Application Programming Interface)가있는 블록체인 플랫폼입니다. Faireum 메인 블록체인은 스마트 콘트랙트 및 BFT (Bezantine Fault Tolerance) + DPOS (Delegated Proof-of-Stat)에 대한 기본 런타임으로 웹 어셈블리 (WASM) 가상 시스템을 컨센서스 메커니즘으로 사용합니다.',

            explainSolution2: 'Faireum 블록체인의 렌덤 남버는 프로그램에서 추론 할 수있는 데이터가 아닙니다. 블록 해시 및 제로 지식 증명과 결합하여 역수를 사용하여 렌덤 남버 생성 프로그램을 추론하거나 예측할 수 없습니다. 이 알고리즘을 제로 랜덤 알고리즘 (Zero Random Algorithm, ZRA)이라고 부릅니다. ',

            explainSolution3: 'ZRA 알고리즘 외에도 Faireum 블록체인은 디지털 게임 전용 Faireum Random Digital (FRD), 카지노 게임 전용 Faireum Random Casino (FRC) 등 여러 다른 Random Number Generators (RNG)로 구성되어 있습니다. 스포츠 퀴즈 (PQ)와 같은 실시간 결과를 위해 사전 설정되어있는 Faireum Dynamic Betting (FDB) 라고 불리는 동적 확률 균형 지수 생성기가 포함되어 있습니다.',

        },

        token: {

            tokenTitle: '토큰 판매 세부 정보',

            tokenRemark: '12 억의 Faireum 토큰이 발행됩니다. Faireum 생태계가 현재 개발되고 있기 때문에 각 Faireum 토큰은 초기에 Ethereum 생태계에서 하나에 해당 ERC20 토큰으로 매핑됩니다. ',

            tokenAllocation: 'Token Allocation',
            fundsAllocation: 'Funds Allocation',

            textJoinIco1: '우리와 함께',

            textJoinIco2: '토큰 판매 목록',

            textStartTip: '예매 시작',

            textPreIco: 'PreSale',

            textPubIco: '공개 판매',

            preIcoDuring: '2019 년 3 월 25 일 ~ 2019 년 4 월 24 일 ',

            pubIcoDuring: '2019 년 6 월 1 일 ~ 2019 년 8 월 31 일',

            bonus: '보너스',

            textSoftCap: '소프트 캡',

            textHardCap: '하드 캡',

            valueSoftCap: '2,500,000 USD',

            valueHardCap: '7,500,000 USD',

            signJoin: '지금 가입',

            textName: '토큰 이름',

            textSymbol: '토큰 심볼',

            textIssuer: '토큰 발행자',

            textSaleSupply: '판매량',

            textTotalSupply: '총 공급량',

            textExchange: '토큰 교환',

            textIcoStart: '토큰 판매 시작',

            textIcoEnd: '토큰 판매 종료',

            textSaleDuring: '판매 기간',

            valueName: 'Faireum Token',

            valueSymbol: 'FAIRC',

            valueIssuer: 'Faireum Foundation Limited',

            valueSaleSupply: '600,000,000 FAIRC',

            valueTotalSupply: '1,200,000,000 FAIRC',

            valueExchange: '1 FAIRC = 0.015 USD',

            valueIcoStart: '2019 년 3 월 25 일 ',

            valueIcoEnd: '2019 년 8 월 31 일 ',

            valueSaleDuring: '4 개월',

        },

        codes: {
            title: 'Faireum 스마트 콘트랙트',
            subtitle: '계약  발표 및 오픈소스',
            remark: '주소:0x437365ffb4c5dd6fd6f9f6ed0b4a9e23d7edc9ce'
        },
        download: {

            title: 'Download',

            subtitle: '우리의 문서 읽기',

            remark: 'Faireum 프로젝트에 관한 문서입니다. 저희를 알아가는데 도움이 되였으면 좋겠습니다.'

        },

        roadmap: {

            roadmapRemark: '저희 팀은 로드맵을 따라서 열심히 노력하고 있습니다.',

            time1: '2017년',

            time2: '2018 년1-3분기',

            time3: '2018 년4분기',

            time4: '2019 년1분기',

            time5: '2019 년2분기',

            time6: '2019년3분기',

            time7: '2019 년4분기',

            time8: '2020 년1분기',

            time9: '2020 년2분기',

            time10: '2020 년3-4분기',

            time11: '2021년1분기',

            title1: '리서치',

            title2: '준비',

            title3: '기술 업그레이드',

            title4: '최소사용가능버전',

            title5: '프레임 워크 개발',

            title6: '앞으로의 개발',

            title7: '테스트넷 온라인',

            title8: ' Faireum업그레이드 ',

            title9: '모듈 확장',

            title10: '메인 넷 온라인',

            title11: 'Faireum 환경',

            roadmap1_1: '시장 조사',

            roadmap1_2: '프로토 타입 디자인',

            roadmap1_3: '게이밍 라이센스 준비',

            roadmap2_1: '엔젤 자금 지원',

            roadmap2_2: '브랜드 등록',

            roadmap2_3: '백서',

            roadmap3_1: '새 웹 사이트',

            roadmap3_2: '크로스 체인& ZKP RNG 디자인',

            roadmap3_3: '게임 프로토콜 디자인',

            roadmap3_4: 'Faireum 프레임 워크 디자인',

            roadmap4_1: 'ICO 준비',

            roadmap4_2: '게임 플랫폼',

            roadmap4_3: 'Faireum 게임',

            roadmap5_1: '거래소 출시',

            roadmap5_2: '네트워크 개발 테스트',

            roadmap5_3: '알파 게임 프로토콜',

            roadmap5_4: '일부 Faireum 게임 개발',

            roadmap6_1: 'Faireum 블록체인 기초 개발',

            roadmap6_2: 'Faireum 월렛 개발',

            roadmap6_3: '일부 Faireum 게임 테스트',

            roadmap7_1: '온라인 네트워크 테스트',

            roadmap7_2: 'Bata버전 Faireum 블록체인 게임 출시',

            roadmap8_1: '메인 네트워크 업그레이드',

            roadmap8_2: ' Faireum 월렛 업그레이드',

            roadmap9_1: 'Faireum VM 디자인 / 개발',

            roadmap9_2: 'Faireum RNG 완성',

            roadmap10_1: 'Faireum 메인넷 출시',

            roadmap10_2: 'Faireum 월렛 출시',

            roadmap10_3: 'Faireum 스마트 콘트랙트 발표',

            roadmap10_4: '메인 넷 토큰 등록',

            roadmap11_1: 'Faireum 플랫폼 출시',

            roadmap11_2: 'Faireum 게이밍 재단 창립',

            roadmap11_3: 'Faireum 환경 확장',

        },

        team: {
            team: "Team member",
            advisor: "Advisor",
        },
        partners: {
            partner: "Partner",
            media: "Media"
        },

        faq: {

            faqRemark: '아래는 Faireum, ICO 및 기타에 관한 질문에 대한 답변입니다. 기타 문의사항 있으시면 아래의 연락창으로 연락 주세요.',

            tagGeneral: '일반',

            tagToken: '기술 및 토큰',

            tagOthers: '기타',

            Q1: 'Faireum은 무엇입니까?',

            Q2: '우리는 왜 Faireum이 필요합니까?',

            Q3: 'Faireum 프로토콜은 무엇입니까?',

            Q4: 'Faireum은 어떻게 공정성과 투명성을 보장 할 수 있습니까?',

            Q5: 'Faireum의 성능은 어떻습니까?',

            Q6: 'Faireum Token의 기능은 무엇입니까?',

            Q7: 'Faireum은 스마트 콘트랙트을 할수 있습니까?',

            Q8: 'Faireum 렌덤 남버 생성기란 무엇입니까?',

            Q9: 'Faireum에서 어떻게 게임합니까?',

            Q10: '우리의 경쟁자는 누구입니까? 그리고 우리의 장점은 무엇입니까? ',

            A1: 'Faireum은 게이밍 산업에 초점을 맞추고 탈중앙화되고 저렴한 비용으로 투명하고 안전한 베팅 및 게이밍 서비스를 제공하는 퍼블릭 블록체인 및 프로토콜 세트입니다.',

            A2_1: '전통적인 게이밍과 중앙화 게이밍 모두 투명성, 처리 효율성, 보안, 신뢰성, 개인 정보 보호 및 익명 성 측면에서 단점이 있습니다.',

            A2_2: '탈중앙화 된 게이밍으로 이러한 문제를 효율적으로 피할 수 있습니다. 그러나 현재 대중적인 공개 체인의 지원은 처리 효율성, 업계 프로토콜, 기본 기능 및 RNG 알고리즘과 같은 다음 측면에서 부족하고 충분하지 않습니다.',

            A2_3: '게다가, 자산 처분, 게이밍 진행중 칩의 변동성, 다양한 자산의 교환에 대한 좋은 해결책은 없습니다. Faireum은 보안 및 투명성, 공개 체인의 고유 한 기능을 결합하고 다양한 프로토콜, 기본 기능, 다중 알고리즘, 교차 체인 자산 스왑 및 병렬 비즈니스 확장 역량과 같은 많은 독창적 기능을 통합합니다.',

            A2_4: '안전하고 공정하며 효율적으로 처리하고 칩 가치를 안정적으로 유지하며 실시간 교환 기능을 갖춘 다양한 산업 모델을 지원하기 위해 게이밍 산업의 프로토콜을 기반으로하는 공개 체인 생태계를 구축하기 위해 노력합니다. 다양한 자산의 Faireum 공개 체인 생태계는 100 % 게이밍 산업에 기여합니다. ',

            A3_1: 'Faireum프로토콜은 속성, 규칙 및 정의의 집합으로 이해할 수 있습니다. 그것은 공통된 사물이나 사건의 집합을 추상적으로 표현한 것입니다. 누구나 특정 기능, 운영, 구현 등을 확장 할 수 있습니다. ',

            A3_2: '자연계에서 인간이 공통적 인 특징을 가지고 있을 때 추상적으로 프로토콜이라 보고 개인의  독립적 성격, 능력, 외관 등 본 프로토콜의 확장이라고 볼수 있습니다.',

            A3_3: 'Faireum에서는 고도로 정제된 추상 프로토콜을 통해 게이밍 공개 체인 생태계를 구축합니다.',

            A4_1:' Faireum은 분산 된 공개 체인 + 프로토콜 솔루션으로서 기본 프레임 워크, 시스템 프레임 워크 및 게임 계약을 공개함으로서 전체 시스템의 공정성과 투명성을 보장하며, 게임 프로세스의 상태, 데이터 및 정산 정보는 블록체인 공개 장부에 기록한다. 이러한 특성은 중앙화 시스템 보다 우월합니다. ',

            A4_2: '기타 분산 시스템이나 공공 체인과 비교할 때, Faireum은 블록 생성, 합의 알고리즘, 다층 구조 및 가상 시스템 설계에 있어서 “랜덤”, ”투명”을 중요시하고 있습니다. 게이밍 산업을 지원할 수있는 랜덤 기본 체인과 프로토콜을 제공하며 Faireum은 게이밍 업계에 유익한 수많은 모델과 특성을 제공하고 있습니다.  ',

            A4_3: ' 이로 인해 Faireum은 게이밍 업계에 가장 적합한 생태계가 될수 있습니다.',

            A5: 'Faireum의 더블 체인 설계와 메인 체인의 BFT + DPOS 합의 알고리즘을 통해Faireum 첫번째 버전의 성능이 3000TPS를 넘을 것으로 예상됩니다.',

            A6: 'Faireum 토큰이 우리의 게이밍 생태계에서 주요 유통 토큰이 될 것입니다. 게임, 추가 서비스 구매, 자산 교환 등에 사용할수 있으며Faireum의 플레이어의 증가로 다양화 될 것입니다. ',

            A7: 'Faireum은 WASM 체계를 가상 시스템의 기본 스마트 콘트랙트 런타임으로 사용합니다. 대부분 WASM을 기준으로 한 (Ethereum, EOS) DApps 및 스마트 콘트랙트은 Faireum의 프로토콜을 통해 쉽게Faireum 블록체인으로 바꿀수 있습니다.',

            A8: ' Faireum 블록체인의 렌덤 남버는 프로그램에서 추론 할 수있는 데이터가 아닙니다. 블록 해시 및 제로 지식 증명과 결합하여 역수를 사용하여 렌덤 남버 생성 프로그램을 추론하거나 예측할 수 없습니다. 이 알고리즘을 제로 랜덤 알고리즘 (Zero Random Algorithm, ZRA)이라고 부릅니다. ',

            A9: 'Faireum 스마트 노드는 게임 센터 역할을 할 수 있습니다. 플레이어는 FSN에서Faireum블록체인 게임을 확인하고 참가할 수 있습니다. 게임이 플레이되거나 공유되면 개발자와 플레이어 모두 Faireum 블록체인의 보상을 받게됩니다. ',

            A10_1: '블록체인 게이밍 플랫폼(Trueflip, Vdice, Casino.dao, FunFair 등), 블록체인(Ethereum 및 EOS등) 및 기타 온라인 게임 등 여러 유형의 경쟁 업체가 있습니다.',

            A10_2: 'Faireum블록체인은 위 플랫폼에서 존재하는 대부분의 문제(투명도, 비용, 성능 등)에 대한 해결책을 제공합니다.',

            A10_3: '현금 관리와 FairCash를 통해 사용자는 “현금”으로 게임을 즐길 수 있습니다.',

            A10_4: 'FSN은 게이밍, 복권 및 퀴즈 게임에 적합화된 플레이어에 친절한 게임센터 입니다. ',

            A10_5: '통합된 B2B 솔루션은 카지노 및 온라인 게임의 스코어에 민첩하게 반응하며 온라인 칩 시스템을 제공 할 수 있습니다.',

        },

        contact: {

            joinTelegram: '우리의 Telegram에 가입하기',

            contactRemark: '의문이 있으시면 언제든지 연락 주세요. 빠른 시일내에 답변 드리겠습니다.',
            subscribeRemark1: '많은 관심 부탁 드립니다.',

            subscribeRemark2: '구독하기',

            subscribeEmailPlaceholder: '이메일 주소 입력',

            getTouch: '우리와 연락하기'

        }
    }

}