var localeJp = {

    common: {

        domain: 'https://faireum.io',

        languageCode: 'Jp',

        language: '日本語',

        projectName: 'Faireum',

        copyright: '©2018-2019 Faireum Foundation Limited。無断複写・転載を禁じます ',

        more: 'More',

        privacyPolicy: 'プライバシーポリシー',

        useTerms: '利用規約',

        riskWarning: '免責事項とリスク警告',

        auditReport: 'スマート契約の監査報告書',

        presentation: 'Faireum presentation',

        dashboard: 'ICO詳細',

        buyTokens: '購入トークン',

        join: '参加する',

        download: 'ダウンロード',

        textIcoStart: '事前販売開始',

        whitepaper: 'ホワイトペーパー',

        onepager: 'OnePager',

        sologan1: 'Once Fair',

        sologan2: 'Always Fair',

        sologanRemark: '`次世代iGamingブロックチェーンネットワークソリューション',

        intro: 'Faireumは,オンラインiGamingぷラットフォームに革命をもたらす業界レベルのパブリックブロックチェーンです。',

        text: {

            days: '日',

            hours: '時間',

            mins: '分',

            secs: '秒',

        },

        inputs: {

            submit: '送信',

            name: '名前',

            email: 'Eメール',

            message: 'メッセージ',

        },

        titles: {

            home: 'ホーム',

            about: 'はじめに',

            business: 'ビジネス',

            problem: '業界問題',

            solution: '解決策',

            token: 'トークン',

            download: 'ダウンロード',

            roadmap: 'ロードマップ',

            partners: 'パートナー',

            team: 'チーム',

            faq: 'よくあ​​る質問',

            contact: '連絡先',

            subscribe: '購読する',

        },
        branding: {
            soldout: '合計50万ドルのFAIRCは前売りで完売した。',
            ieosoon: '第1ラウンドはIEOの5万ドル札が1時間で完売した。',
            ieoRounds: "IEO轮数",
            ieoRaised: "第1ラウンドIEO調達資金の額",
            ieoCap: "IEO下轮",
            waitingPay: "支払い保留",
            raised: "PRE-ICO調達資金の額",
            processing: "支払い処理",
            brandingRating: "Faireumは誇らしげに私たちが世界でトップ5のICO評価ウェブサイトに勝ったことを発表しました。",
            brandingExchanges: "Faireumは、ICO終了後、世界のトップ10のうち少なくとも3つの取引所に上場する予定です。",
            brandingMedia: "Faireumプロジェクトに関する情報とレポートを公開している、100以上の主流のニュースメディアチャンネルがあります。",
            brandingPandora: "Faireumは5月中旬頃に新しく革新的なゲームプラットフォームを立ち上げるでしょう",
            brandingJapan: "Faireumは強力なブランドの影響力を一般に公開することを目的とした合法的な運営プロジェクトです。",
            brandingSecurity: "Faireumのスマート契約は、世界をリードするセキュリティ監査会社SmartDecのセキュリティ監査に合格しました。",
            brandingEconomic: "私達はいつでも歓迎し、あなたの投資ニーズを満たします！",
        }
    },
    module: {
        platform: {
            title: 'Faireumゲーム',
            description: 'Faireumプラットフォームで多様なゲームをお試しいただけます。',
            remark: 'Faireumゲームプラットフォーム上には既にリリースされている数千個ものゲーム(Betaバージョン)がございます。今すぐ加入し、Faireumプラットフォームでゲームの旅を始めましょう。'
        },
        about: {

            whatFaireum: 'Faireumとは何ですか？',

            explainFaireum1: 'Faireumは一つのパブリックブロックチェーンと多数のプロトコルによって組み立てられます。iGaming業界の問題に焦点を当て分散型、低コスト、透明で安全なギャンブル体験を提供いたします。',

            explainFaireum2: 'Faireumは独自トークンと自由ゲーム契約を介してユーザーに宝くじ、馬券、スポーツベッティング、カジノゲーム、その他多数の優れた賭け体験を保証します。',

            explainFaireum3: 'Faireumノード以外にも、スマートクライアントもFaireumのプロトコルと連携して動作し安全でスムーズなオンラインゲームを体験していただけます。',

            basicFramework: '基本フレーム',

            explainBasicFramework1: 'Faireumは業界レベルのパブリックブロックチェーンを開発し、iGamingプラットフォームとしての技術的基盤を固めました。',

            explainBasicFramework2: 'Faireumブロックチェーンエコシステムには,元帳ノード、P2Pネットワーク、スマート契約仮想機、およびトークン獲得、お支払い窓口、デジタル資産交換、およびクロスチェーンアトミックスワップを含む一連のトークン配布法則が含まれます。',

        },

        business: {

            gamesOnFaireum: ' Faireumブロックチェーン上のゲーム',

            gamesRemark: 'オフィシャルゲームとプロバイダーから厳選提供されたゲームなどを含む数百種類のゲームを私達のプラットフォームからご利用いただけます。',

            gamesLottery: '宝くじ',

            gamesCasino: 'カジノ',

            gamesDigital: 'デジタルゲーム',

            gamesBetting: 'スポーツベッティング',

            gamesLotteryRemark: '宝くじとは数字の組み合わせに賞金がかかっている一種のギャンブルです。',

            gamesCasinoRemark: 'カジノはさまざまなギャンブル活動やゲームを有し、顧客はそこで確率に基づいたゲームをプレイできます。',

            gamesDigitalRemark: 'オンラインデジタルゲームは可視化ギャンブルとして従来のギャンブルより歴史は浅いものの、すでに競技できるレベルまでに成長しています。',

            gamesBettingRemark: 'スポーツベッティングはスポーツイベントの結果や事件を予測し賭けを置くことを含みます。',

            ourApps: 'Faireumビジネスアプリケーション',

            smartNode: 'スマートノード',

            smartNodeRemark: 'Faireumスマートノード（FSN）は、ユーザのコンピュータやスマートフォン端末上で動作するblockchainノードであり、ユーザ側のお財布機能とサーバー側のプロキシ機能両方の役割を担います',

            explainSmartNode1: 'blockchainノードサービスとして機能します。',

            explainSmartNode2: 'クライアントサービス統合として機能します。',

            explainSmartNode3: 'blockchain財布またはゲームセンターとして機能できます。',
            explainSmartNode4: 'スマートノードパートナーサービスまたはスマートエクスチェンジなどの交易を行えます。',

        },

        solution: {

            problemsTitle: 'ギャンブル業界の問題点',

            problemsRemark: '近頃、iGaming、ギャンブル業界に次のような問題に差し迫っています。',

            solutionTitle: 'Faireumブロックチェーンソリューション',

            transparency: '安全性と透明性の欠如',

            negative: '否定的な社会的評判',

            unfair: '不公平なオッズ',

            fees: '高い手数料',

            security: 'セキュリティ',

            tax: '脱税やマネーロンダリング',

            transparencyRemark: '集中管理されたシステムはリソース閉じ込めるため、外部から研究開発に参与することは困難です。',

            negativeRemark: 'プレイヤーはライブゲームの相手方に対して強い不確実性と不信感を抱いています。',

            unfairRemark: 'プラットフォームはパラメータを変更することによって乱数発生器（RNG）を改ざでき、プレイヤーに対するオッズを脅かします。',

            feesRemark: 'ギャンブルプラットフォームの収益モデルはが高い利用費用をもたらしました。',

            securityRemark: '集中型システムは100％のセキュリティを保証できず、バグの受容性も低かったです。',

            taxRemark: 'ゲームは多くの場合ローカルの税収システムに同調しておらず、マネーロンダリングのリスクがあります。',

            explainSolution1: 'Faireumは第三者のビジネスプロバイダーにApplication Programming Interface（API）を提供します。プロバイダーは合意規則とFaireum Virtual Machine（FVM）を介してFaireumメインブロックチェーンにアクセスしWeb Assembly（WASM）仮想マシンを使用しスマートコントラクトを結び、合意メカニズムとしてByzantine Fault Tolerance（BFT）+代理証明（DPos）を使用していただけます。',

            explainSolution2: 'Faireumブロックチェーンからの乱数はプログラムから推測できるデータだけではありません。ブロックハッシュとゼロ知識証明とを組み合わせ、逆行列を使用して乱数を推定予測することはできません。このアルゴリズムをゼロランダムアルゴリズム（ZRA）と呼びます。',

            explainSolution3: 'FaireumブロックチェーンはZRAアルゴリズムに加えてデジタルゲーム専用のFaireum Random Digital（FRD）、カジノゲーム専用のFaireum Random Casino（FRC）、スポーツベッティング専用のFaireum Dynamic Betting（FDB）と呼ばれる動的確率バランス指数生成器など多種類乱数ジェネレータ（RNG）を設置しております。',

        },

        token: {

            tokenTitle: 'トークン販売詳細情報',

            tokenRemark: '12 億のFaireumトークンが発行されます。Faireumエコシステムは現在開発中であるため各Faireumトークンは最初にEthereumエコシステム上ERC20トークンと1:1マッピングされます。',

            tokenAllocation: 'トークン配分',

            fundsAllocation: '資金配分',

            textJoinIco1: '参加してください',

            textJoinIco2: 'トークンセール一覧',

            textStartTip: '先行販売の開始',

            textPreIco: 'PreSale',

            textPubIco: 'パブリックセール',

            preIcoDuring: '2019年3月25日〜2019年4月24日',

            pubIcoDuring: '2019年6月1日〜2019年8月31日',

            bonus: 'ボーナス',

            textSoftCap: 'ソフトキャップ',

            textHardCap: 'ハードキャップ',

            valueSoftCap: '2,500,000 USD',

            valueHardCap: '7,500,000 USD',

            signJoin: '今すぐ登録',

            textName: 'トークン名',

            textSymbol: 'トークンシンボル',

            textIssuer: 'トークン発行者',

            textSaleSupply: 'セールス量',

            textTotalSupply: '合計量',

            textExchange: 'トークン為替',

            textIcoStart: 'トークン販売開始',

            textIcoEnd: 'トークン販売終了',

            textSaleDuring: '販売期間',

            valueName: 'Faireumトークン',

            valueSymbol: 'FAIRC',

            valueIssuer: 'Faireumファンデーションリミテッド',

            valueSaleSupply: '600,000,000 FAIRC',

            valueTotalSupply: '1,200,000,000 FAIRC',

            valueExchange: '1 FAIRC = 0.015 USD',

            valueIcoStart: '2019年3月25日',

            valueIcoEnd: '2019年8月31日',

            valueSaleDuring: '4ヶ月間',

        },
        codes: {
            title: 'Faireum スマート契約',
            subtitle: '契約書は既に発表およびオープンした',
            remark: 'アドレス:0x437365ffb4c5dd6fd6f9f6ed0b4a9e23d7edc9ce'
        },
        download: {

            title: 'ダウンロード',

            subtitle: '私たちの文書を読む',

            remark: 'Faireumプロジェクトに関する文書の全リスト'

        },

        roadmap: {

            roadmapRemark: '私達のチームはロードマップに沿って日々努力しております。',

            time1: '2017 全年度',

            time2: '2018年第1～3半期',

            time3: '2018年第4四半期',

            time4: '2019年第1四半期',

            time5: '2019年第2四半期',

            time6: '2019年第3四半期',

            time7: '2019年第4四半期',

            time8: '2020年第1四半期',

            time9: '2020年第2四半期',

            time10: '2020年第３～４四半期',

            time11: '2021年第1四半期',

            title1: '研究',

            title2: '準備',

            title3: '技術のアップグレード',

            title4: 'MVP',

            title5: 'フレームワークの開発',

            title6: 'さらなる開発',

            title7: 'TestNetオンライン',

            title8: 'アップグレードFaireum',

            title9: 'モジュール拡張',

            title10: 'メインネットオンライン',

            title11: 'Faireum環境',

            roadmap1_1: '市場調査',

            roadmap1_2: 'プロトタイプデザイン',

            roadmap1_3: 'ギャンブルライセンスの準備',

            roadmap2_1: 'エンジェル資金',

            roadmap2_2: 'ブランド登録',

            roadmap2_3: '白書',

            roadmap3_1: '新しいオフィシャルウェブサイト',

            roadmap3_2: 'クロスチェーン＆ZKP RNGデザイン',

            roadmap3_3: 'ゲームプロトコル設計',

            roadmap3_4: 'Faireumフレームデザイン',

            roadmap4_1: 'ICO準備',

            roadmap4_2: 'iGamingプラットフォーム',

            roadmap4_3: 'Faireumゲーム',

            roadmap5_1: 'エクスチェンジリスト',

            roadmap5_2: 'テストネットワーク開発',

            roadmap5_3: 'アルファ版ゲームプロトコル発表',

            roadmap5_4: '部分Faireumゲーム開発',

            roadmap6_1: 'Faireumブロックチェーンレイヤーの開発',

            roadmap6_2: 'Faireum財布開発',

            roadmap6_3: '部分Faireumゲーム発表',

            roadmap7_1: 'ネットワークのオンラインテスト',

            roadmap7_2: 'Partial Faireumのゲームリリース',

            roadmap8_1: 'メインネットワークをアップグレードする',

            roadmap8_2: 'アップグレードFaireum財布',

            roadmap9_1: 'Faireum VMの設計/開発',

            roadmap9_2: 'Faireum RNGの完成',

            roadmap10_1: 'Faireum メインネットオンライン',

            roadmap10_2: 'Faireumお財布リリース',

            roadmap10_3: 'Faireumのスマート契約を発表',

            roadmap10_4: 'メインネットトークン登録',

            roadmap11_1: 'Faireumプラットフォームオンライン',

            roadmap11_2: 'Faireumギャンブル財団',

            roadmap11_3: 'Faireum規模拡張',

        },

        team: {
            team: "チームメンバー",
            advisor: "コンサルタント",
        },
        partners: {
            partner: "協力パートナー",
            media: "マスコミ報道"
        },

        faq: {

            faqRemark: '以下は私たちのICO、トークン、その他に関する質問に対する答えです。',

            tagGeneral: '一般',

            tagToken: 'テクニカル＆トークン',

            tagOthers: 'その他の',

            Q1: 'Faireumとは何ですか？',

            Q2: 'なぜFaireumが必要なのですか？',

            Q3: 'Faireumプロトコルは何ですか？',

            Q4: 'Faireumの公平性と透明性をどのように確保しますか？',

            Q5: 'Faireumのパフォーマンスはどうですか？',

            Q6: 'Faireum トークンの機能は何ですか？',

            Q7: 'Faireumはスマート契約をサポートしていますか？',

            Q8: 'Faireum乱数ジェネレータとは何ですか？',

            Q9: 'Faireumでゲームをプレイするにはどうすればいいですか？',

            Q10: '競合他社は誰ですか？そして私たちの利点は何ですか？',

            A1: 'Faireumは一本のパブリックブロックチェーンと複数のプロトコルで組み立てられ、分散型、低コスト、透明で安全なiGaming経験を提供します。',
            A2: '伝統的ギャンブルと集中ギャンブルのどちらにも、透明性、処理効率、セキュリティ、信頼性、プライバシーおよび匿名性の面で欠点があります。分散ギャンブルはこれらの問題を効率的に回避することができます。しかし現在のところ処理効率、業界のプロトコル、基盤となる機能およびRNGアルゴリズムなどの点では一般的なパブリックチェーンからのサポートは限られ、不十分です。さらに資産の処分、ギャンブル中のチップのボラティリティおよびさまざまな資産の交換に関する優れた解決策はありません。Faireumは,セキュリティと透明性、パブリックチェーンの独特の機能を組み合わせ、多様なプロトコル、ネイティブ機能、複数のアルゴリズム、クロスチェーンアセットスワップ、並行事業拡大の能力など、多くの独自機能に組み込んでいます。私たちは、ギャンブル業界のプロトコルに基づいたパブリックチェーンのエコシステムの構築、安全で公平な処理の効率化、チップ価値の安定化そしてさまざまな資産のリアルタイム交換機能を伴う多様な業界モデルのサポートに努めます。Faireumパブリックチェーンエコシステムは、ギャンブル業界に100％貢献しています。',

            A2_1: '伝統的ギャンブルと集中ギャンブルのどちらにも、透明性、処理効率、セキュリティ、信頼性、プライバシー、および匿名性の点で欠点があります。',

            A2_2: '分散ギャンブルはこれらの問題を効率的に回避することができます。しかし現在のところ処理効率、業界のプロトコル、基盤となる機能およびRNGアルゴリズムなどの点では一般的なパブリックチェーンからのサポートは限られ、不十分です。',

            A2_3: 'さらに資産の処分、ギャンブル中のチップのボラティリティおよびさまざまな資産の交換に関する優れた解決策はありません。Faireumは,セキュリティと透明性、パブリックチェーンの独特の機能を組み合わせ、多様なプロトコル、ネイティブ機能、複数のアルゴリズム、クロスチェーンアセットスワップ、並行事業拡大の能力など、多くの独自機能に組み込んでいます。',

            A2_4: '私たちは、ギャンブル業界のプロトコルに基づいたパブリックチェーンのエコシステムの構築、安全で公平な処理の効率化、チップ価値の安定化そしてさまざまな資産のリアルタイム交換機能を伴う多様な業界モデルのサポートに努めます。Faireumパブリックチェーンエコシステムは、ギャンブル業界に100％貢献しています。',

            A3_1: 'プロトコルは属性、規則および定義の集まりとして理解できます。それはイベントセットの抽象表現であり、誰もこれを元にが特定の機能、操作、実装などを拡張できます。',

            A3_2: '例えば自然の中で人間共通の特徴もプロトコルに抽象化できるのと同様に、個人の独立した性格、能力、外観などはこのプロトコルの拡張です。',

            A3_3: 'Faireumでは賭けをするパプリックチェーンエコシステム全体が高度に洗練された抽象プロトコルによって構築されています。',

            A4_1: '分散型パブリックチェーン+プロトコルソリューションとして、Faireumはオープンソースの基礎となるフレームワーク、システムフレームワーク、およびゲーム契約を通じてシステム全体の公平性と透明性を保証します。一方、ゲームプロセスにおける状態、データおよび決済情報はブロックチェーンのパブリック元帳に記録されます。',

            A4_2: 'パブリック元帳の記録は本質的に集中型システムの設計より記録に優れています。',

            A4_3: '他の分散型システムやパブリックチェーンと比較してFaireumは「ランダム」および「透明化」の標準に従いブロック生成、コンセンサスアルゴリズム、多層構造から仮想マシン設計まで純粋にランダムな基盤となるチェーンを提供します。ギャンブル業界に役立つことができるテンプレートと機能の数。これによりFaireumはギャンブル業界で最も適したエコシステムになります。',

            A5: 'Faireumの最初のバージョンのパフォーマンスはその二重層設計とメインブロックチェーンのBFT + DPOSコンセンサスアルゴリズムにより3000 TPSを超えると予想されます。',

            A6: 'Faireum トークンは私たちのギャンブルエコシステムの主要な循環トークンになります。機能の向上とパートナーの設立に伴いFaireum トークンの適用は多様化するでしょう。',

            A7: 'FaireumはWASM仮想マシンをデフォルトのスマートコントラクトランタイムとして統合しています。WASMをサポートすることでEthereum、EOSおよびWASMに基づく他のブロックチェーン規格のために書かれたDAppsとスマートコントラクトのほとんどはFaireumブロックチェーンに簡単に移行できます。',

            A8: 'ブロックハッシュとゼロ知識証明を組み合わせると,私たちの乱数生成器はいかなる逆行列によっても推定または事前推定することはできません。このアルゴリズムをゼロランダムアルゴリズム（ZRA）と呼びます。',

            A9: 'Faireum スマートノードはゲームセンターとして機能することができます。プレイヤーはFSNからゲームのリストを閲覧し、ゲームを起動/プレイすることができます。ゲームがプレイされ共有されると開発者とプレイヤーの両方がFaireumブロックチェーンによって報酬を得ます。',

            A10_1: '私たちには多種類の競争相手がいます:ブロックチェーンギャンブルプラットフォーム（Trueflip、Vdice、Casino.dao、FunFairを含む）。ブロックチェーン（EthereumおよびEnterprise Operation Systemを含む）およびその他のオンラインゲームプラットフォーム。',

            A10_2: 'Faireumは上記ほとんどのプラットフォームにある問題に対する解決策を提供します。',

            A10_3: '資金管理とFairCashを使えばユーザーは実質のお金で遊ぶことができます',

            A10_4: 'FSNはギャンブル、宝くじそして推測ゲームフォーマットに特化したユーザーフレンドリーなゲームセンターです。一般ユーザーは自分の携帯電話にアプリをダウンロードするか、ブラウザを介してアクセスして即座にゲームをプレイすることができます。',

            A10_5: '統合されたB2BソリューションはiGamingに非常に柔軟なスコアとオンラインチップシステムを提供することができます。',

        },

        contact: {

            joinTelegram: 'Telegramに参加してください',

            contactRemark: '質問がありますか？私達に連絡ください。すぐに返答いたします。',

            subscribeRemark1: '更新をお見逃しなくチェックしてください。',

            subscribeRemark2: '購読',

            subscribeEmailPlaceholder: 'Eメールアドレスを入力してください',

            getTouch: '私たちに連絡をください'

        }

    }

}
