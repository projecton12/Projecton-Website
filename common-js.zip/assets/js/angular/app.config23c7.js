/**
 * Created by eric on 2018/9/17.
 */
/**
 * Annyee.config.
 */

(function() {
    var module = angular.module("app.config", []);
    module.factory("appConfig", ["$rootScope", appConfig]);

    console.log('Console app.config loaded');

    function appConfig() {

        return {
            HOST: "https://Projecton.pro/",
            
        };
    }
}());
