(function() {
    'use strict';

    // Angular modules definition
    var mainApp = angular.module('mainApp', [
        'ngRoute',                      // sub page navigation
        'app.config',
        'pascalprecht.translate'
    ]);

    /**
     * 毫秒转换友好的显示格式
     * 输出格式：21小时前
     * @param  {[type]} time [description]
     * @return {[type]}      [description]
     */
    mainApp.filter('datestr',function(){
        return function (date){

            //获取js 时间戳
            var time=new Date().getTime();
            //去掉 js 时间戳后三位，与php 时间戳保持一致
            time=parseInt((time-date*1000)/1000);

            //存储转换值
            var s;
            if(time<60){
                s = time;
                return  s+" sec ago";
            }else if((time<60*60)&&(time>=60)){
                s = Math.floor(time/60);
                return  s+" min ago";
            }else if((time<60*60*24)&&(time>=60*60)){
                //超过1小时少于24小时
                s = Math.floor(time/60/60);
                return  s+" hours ago";
            }else if((time<60*60*24*3)&&(time>=60*60*24)){
                //超过1天少于3天内
                s = Math.floor(time/60/60/24);
                return s+" days ago";
            }else{
                //超过3天
                var date= new Date(parseInt(date) * 1000);
                return date.getFullYear()+"/"+(date.getMonth()+1)+"/"+date.getDate();
            }
        }
    });

    mainApp.filter('sec2date',function(){
        return function (time){

            time = Math.round(time/1000)

            //存储转换值
            var s;
            if(time<60){
                s = time;
                return  s+" sec ago";
            }else if((time<60*60)&&(time>=60)){
                s = Math.floor(time/60);
                return  s+" min ago";
            }else if((time<60*60*24)&&(time>=60*60)){
                //超过1小时少于24小时
                s = Math.floor(time/60/60);
                return  s+" hours ago";
            }else if((time<60*60*24*3)&&(time>=60*60*24)){
                //超过1天少于3天内
                s = Math.floor(time/60/60/24);
                return s+" days ago";
            }else{
                //超过3天
                var date= new Date(parseInt(date) * 1000);
                return date.getFullYear()+"/"+(date.getMonth()+1)+"/"+date.getDate();
            }
        }
    });

    mainApp.controller('AppCtrl', AppCtrl);


    /**
     * Routing setting
     */
    mainApp.config(function($routeProvider, $locationProvider) {
        $routeProvider
            .when('/', {
                templateUrl : 'pages/home.html',
                controller  : 'HomeCtrl'
            })
            .otherwise({
                templateUrl : 'pages/home.html',
                controller  : 'HomeCtrl'
            });

        $locationProvider.html5Mode({
            enabled: true,
            requireBase: false
        });
    });

    /**
     * I18n setting
     */
    mainApp.config(function ($translateProvider) {

        var translator = $translateProvider.translations('En', localeEn)
            .translations('Tw', localeTw)
            .translations('Jp', localeJp)
            .translations('Kr', localeKr);

        var lang = navigator.language||navigator.userLanguage;//常规浏览器语言和IE浏览器
        lang = lang.substr(0, 2);//截取lang前2位字符
        if(lang == 'zh'){
            translator.preferredLanguage('Tw');
        }else if(lang == 'ja'){
            translator.preferredLanguage('Jp');
        }else if(lang == 'ko'){
            translator.preferredLanguage('Kr');
        }else{
            translator.preferredLanguage('En');
        }
    });

    /**
     * App Controller
     */


    /**
     * Remember confirmed transactions to avoid twice notifications.
     * @type {String[]}
     */


    AppCtrl.$inject = ['$scope', 'appConfig', '$translate'];

    function AppCtrl ($scope, appConfig, $translate) {
        console.log("Angular loaded")

        $scope.dashboard = appConfig.DASHBOARD;
        $scope.ieoLink = appConfig.IEOLINK;

        $scope._members = [
            {
                name: 'Dwayne Austin',
                position: 'CEO',
                description: '',
                linkedin: 'https://www.linkedin.com/in/Dwayne-austin/',
            },
            {
                name: 'Argan Megariansyah',
                position: 'Blockchain Expert',
                description: '',
                linkedin: 'https://www.linkedin.com/in/argan-megariansyah-65751a89/',
            },
            {
                name: 'Gupta lokesh',
                position: 'Blockchain Expert & UI Designer',
                description: '',
                linkedin: 'https://www.linkedin.com/in/me-gupta-lokesh//',
            },
            {
                name: 'Victor Pliego',
                position: 'CEO of GaintDEX',
                description: '',
                linkedin: 'https://www.linkedin.com/in/victor-pliego',
            },
            {
                name: 'Thayne Swindell',
                position: 'Marketer & Advisor',
                description: '',
                linkedin: 'https://www.linkedin.com/in/thayne-swindell-82091a162/',
            },
            {
                name: 'Muhammed mubeen',
                position: 'UI Expert',
                description: '',
                linkedin: 'https://www.linkedin.com/in/maxim-byakow-574238117/',
            },
            {
                name: 'Dheeraj Nuka',
                position: 'Ideaman',
                description: '',
                linkedin: 'Dheeraj Nuka',
            },
            {
                name: 'Shantu Rajput',
                position: 'Community Manager',
                description: '',
                linkedin: 'https://www.linkedin.com/in/shyam-thakur-42a32346',
            },
            
        ];

        $scope._advisors = [
            {
                name: 'Nicolas Fleiderman',
                position: 'iGaming advisor',
                description: '',
                linkedin: 'https://www.linkedin.com/in/nicolasfleiderman/',
            },
            {
            name: 'Eugene Lavrinenko',
                position: 'iGaming Advisor',
                description: '',
                linkedin: 'https://www.linkedin.com/in/eugene-lavrinenko-29260384/',
            },
            {
                name: 'Marcin Zduniak',
                    position: 'Blockchain Advisor',
                    description: '',
                    linkedin: 'https://www.linkedin.com/in/marcinzduniak/',
            },
            {
                name: 'Gregory Tkach',
                    position: 'Blockchain Advisor',
                    description: '',
                    linkedin: 'https://www.linkedin.com/in/gregorytkach/',
            },
        ]

        $scope._partners = [
            {name: "1x2gaming", links: "oingecko.com/en/coins/projecton" },
            {name: "ZEUSPLAY", links: "" },
            {name: "smartdec", links: "" },
            {name: "tokenget", links: "" },
            {name: "wm-worldmatch", links: "" },
            {name: "WAZDAN", links: "" },
            {name: "Tradologic", links: "" },
            {name: "tom-horn", links: "" },
            {name: "spinomenal", links: "" },
            {name: "Spigo", links: "" },
            {name: "realistic", links: "" },
            {name: "realgametombola", links: "" },
            {name: "PRAGMATICPLAY", links: "" },
            {name: "playson", links: "" },
            {name: "PLAY-NGO", links: "" },
            {name: "patagonia", links: "" },
            {name: "OMIGaming", links: "" },
            {name: "NYXGaming", links: "" },
            {name: "NEXTGEN", links: "" },
            
        ]

        $scope._medias = [
            {name: "Cointelegraph", links: "" },
            {name: "Nasdaq", links: "https://www.nasdaq.com/press-release/no-more-high-extra-fees-can-the-new-servicebased-blockchain-business-model-deliver-20190130-01029" },
            {name: "CCN", links: "https://www.ccn.com/the-faireum-blockchain-a-new-way-to-invest-play-and-everything-in-between/" },
            {name: "Forbes", links: "https://www.forbes.com/sites/geraldfenech/2019/02/01/can-a-new-service-based-blockchain-business-model-deliver-for-online-gaming/#4383360f3f46" },
            {name: "YahooFinance", links: "https://finance.yahoo.com/news/no-more-high-extra-fees-203200476.html" },
            {name: "Blockonomi", links: "https://blockonomi.com/the-faireum-blockchain/" },
            {name: "Bittimes", links: "https://bittimes.net/news/47071.html" },
            {name: "TheBitcoinNews", links: "https://thebitcoinnews.com/the-faireum-blockchain-a-new-way-to-invest-play-and-everything-in-between/" },
            {name: "Smartereum", links: "https://smartereum.com/46941/the-faireum-blockchain-a-new-way-to-invest-play-and-everything-in-between/" },
            {name: "Bitcoin", links: "https://news.bitcoin.com/in-the-daily-token-launchpads-proliferate-crypto-movie-faireum-gaming/" },
            {name: "MSNBC", links: "http://tyler-penske.people.msnbc.com/_news/2019/03/06/38742863-crypto-winter-the-perfect-time-for-investors" },
            {name: "MoneyInCrypto", links: "http://moneyincrypto.com/2019/01/20/the-faireum-blockchain-a-new-way-to-invest-play-and-everything-in-between/" },
            {name: "KryptoNachrichten", links: "https://krypto-nachrichten.com/die-faireum-blockchain-eine-neue-art-zu-investieren-zu-spielen-und-alles-dazwischen/" },
            {name: "Investing.com", links: "https://in.investing.com/analysis/no-more-extra-fees-will-this-new-servicebased-blockchain-model-deliver-200208010" },
            {name: "Hacker_Noon", links: "https://hackernoon.com/blockchain-in-2019-trends-and-the-future-9aee88399d18" },
            {name: "EthereumWorldNews", links: "https://ethereumworldnews.com/the-faireum-blockchain-a-new-way-to-invest-play-and-everything-in-between/" },
            {name: "Digital-Journal", links: "http://www.digitaljournal.com/pr/4134416" },
            {name: "Daily-Herald", links: "http://finance.dailyherald.com/dailyherald/news/read/37672663/No_More_High_Extra_Fees" },
            {name: "CoinIdol", links: "https://coinidol.com/faireum-blockchain-new-way-to-invest/" },
            {name: "CoinGape", links: "https://coingape.com/pr-faireum-blockchain-new-way-invest-play-everything/" },
            {name: "BuzzFeed", links: "https://www.buzzfeed.com/nvocvge/jxc-3tf8f" },
            {name: "ZyCrypto", links: "https://zycrypto.com/the-faireum-blockchain-a-new-way-to-invest-play-and-everything-in-between/" },
        ]

        $scope.switchLanguage = function (key) {
            $translate.use(key);
        };
    }
})();